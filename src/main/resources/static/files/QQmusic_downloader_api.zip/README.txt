---------------------------------------------------------------------------------

       This is a simple api which can help you download musics from QQ music's home page without 
downloading the app.  (QQ music is always downloaded with some other malicious tricks at the same time 
which may have a negative influence on your computer)

qqmusic: Directory to save musics.
QQmusic.py: Code to run. 
sign.js:  It is used to decode a encrypted parameter named token. 