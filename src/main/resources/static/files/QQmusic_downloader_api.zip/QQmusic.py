# coding=utf-8
import requests
import execjs
import re
import json
from lxml import etree
import os


class QQmusic():
    def __init__(self, song):
        self.song = song
        self.songid = None
        self.search_url = 'https://y.qq.com/portal/search.html#w={}'.format(self.song)
        self.searchinfo_url = 'https://c.y.qq.com/soso/fcgi-bin/client_search_cp?w={}'.format(self.song)
        self.search_headers = {
            'Referer': 'https://y.qq.com/portal/search.html',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
        }
        self.get_songinfo_headers = {'accept': 'application/json, text/javascript, */*; q=0.01',
                                     'accept-language': 'zh-CN,zh;q=0.9',
                                     'origin': 'https://y.qq.com',
                                     'referer': 'https://y.qq.com/',
                                     # 'cookie': 'pgv_pvi=1560773632; eas_sid=F196w0G8q2M970i9L6q2v544v2; pgv_pvid=2505141056; RK=dczBMYMikm; ptcz=d49b7a65b6af70dd9af8bbf0aab915137885d3e39bc228f73fc0dee8d80722f1; ts_uid=2228589319; tmeLoginType=2; euin=oKnAoKEsoKEPoc**; _ga=GA1.2.1641509424.1608711616; pac_uid=0_fc2b5c2e718d0; pgv_info=ssid=s4187567467; ts_refer=www.baidu.com/link; _qpsvr_localtk=0.7499732774720707; ptui_loginuin=1021961942; qqmusic_fromtag=66; userAction=1; yqq_stat=0; yq_playschange=0; player_exist=1; yq_playdata=; psrf_qqopenid=FE72C2985F548FA5CB5E7F4E2246739F; uin=1021961942; psrf_qqunionid=; qqmusic_key=Q_H_L_2uTBC060eSZDWEwBUH-P16OJOes_WmvTrdq_GVGBKsJj_XQMeOqhcxQ4WAvlkH1; psrf_musickey_createtime=1611410910; qm_keyst=Q_H_L_2uTBC060eSZDWEwBUH-P16OJOes_WmvTrdq_GVGBKsJj_XQMeOqhcxQ4WAvlkH1; psrf_access_token_expiresAt=1619186910; psrf_qqrefresh_token=05309BBAADC89BF198D6A5C563373B26; psrf_qqaccess_token=DAEB4AD4299CFF7D5EA9931787AEC5FD; ts_last=y.qq.com/portal/player.html; yplayer_open=1; yq_index=0',
                                     'sec-ch-ua': '"Google Chrome";v="87", " Not;A Brand";v="99", "Chromium";v="87"',
                                     'sec-ch-ua-mobile': '?0',
                                     'sec-fetch-dest': 'empty',
                                     'sec-fetch-mode': 'cors',
                                     'sec-fetch-site': 'same-site',
                                     'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'}
        self.song_headers = {'accept': '*/*',
                             'accept-language': 'zh-CN,zh;q=0.9',
                             'origin': 'https://y.qq.com',
                             'referer': 'https://y.qq.com/',
                             'sec-ch-ua': '"Google Chrome";v="87", " Not;A Brand";v="99", "Chromium";v="87"',
                             'sec-ch-ua-mobile': '?0',
                             'sec-fetch-dest': 'audio',
                             'sec-fetch-mode': 'no-cors',
                             'sec-fetch-site': 'same-site',
                             'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36', }
        self.data = {"req": {"module": "CDN.SrfCdnDispatchServer", "method": "GetCdnDispatch",
                             "param": {"guid": "2505141056", "calltype": 0, "userip": ""}},
                     "req_0": {"module": "vkey.GetVkeyServer", "method": "CgiGetVkey",
                               "param": {"guid": "2505141056", "songmid": [None], "songtype": [0],
                                         "uin": "1021961942", "loginflag": 1, "platform": "20"}},
                     "comm": {"uin": 706337979, "format": "json", "ct": 24, "cv": 0}}

    def search_song(self):
        response = requests.get(self.searchinfo_url, headers=self.search_headers)
        # print(response.content.decode())
        songinfo = re.findall('callback\((.*)\)', response.content.decode())[0]
        song_list = json.loads(songinfo)['data']['song']['list']
        content = []
        i = 1
        for song in song_list:
            item = {}
            item['id'] = i
            item['songname'] = song['songname']
            item['singer'] = song['singer'][0]['name']
            print(item)
            item['songid'] = song['strMediaMid']
            item['songmid'] = song['songmid']
            i += 1
            content.append(item)
        return content

    def get_sign(self):
        self.data = json.dumps(self.data, ensure_ascii=False)

        # input your sign.js directory here
        signjs_directory = 'CrawlProjects/QQ音乐/sign.js'

        with open(signjs_directory, 'r', encoding='utf-8') as f:
            sign_js = f.read()
        sign = execjs.compile(sign_js).call('get_value', self.data)
        return sign

    def save_music(self, song_name, song_url):
        # input your directory for downloading here
        files_directory = "CrawlProjects/QQ音乐/qqmusic"
        with open(files_directory + "/{}.mp4".format(song_name), 'wb') as f:
            f.write(requests.get(song_url, headers=self.song_headers).content)

    def get_music_response(self, songname):
        sign = self.get_sign()
        # print('https://u.y.qq.com/cgi-bin/musics.fcg?sign={}&data={}'.format(sign, self.data))
        # print(sign)
        response = requests.get(
            'https://u.y.qq.com/cgi-bin/musics.fcg?sign={}&data={}'.format(sign, self.data),
            headers=self.get_songinfo_headers)
        song_info = json.loads(response.content.decode())
        # print(song_info)
        song_url = 'https://ws.stream.qqmusic.qq.com/' + song_info['req_0']['data']["midurlinfo"][0]['purl']
        print(song_url)
        self.save_music(songname, song_url)

    def run(self):
        content = self.search_song()
        num = int(input('please choose a song you want to download(Input the number):'))
        if num not in range(1, 20):
            print('Please input again')
            return False
        for song in content:
            if song['id'] == num:
                songname = str(song['songname']) + '-' + song['singer']
                self.data["req_0"]["param"]["songmid"] = [song['songmid']]
                self.get_music_response(songname)
                print('Download successfully!')
                break


if __name__ == '__main__':
    print(os.chdir('F:\\pycharm'))
    print(os.getcwd())

    # input the song you want to download
    songname = "what you want to"
    qqmusic = QQmusic(songname)
    qqmusic.run()
